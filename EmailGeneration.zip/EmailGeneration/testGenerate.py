from random import *

#Gets random line in txt file
def randLine(inFileName):

	file = open(inFileName,"r")

	fileLines = file.read().splitlines()

	lineNum = randint(0,(len(fileLines)-1))

	return fileLines[lineNum]

#Generates relevant text of email
def genText(inName,inSuffix):
	suffix = inSuffix
	greet = "txt/Greetings" + suffix + ".txt"
	part1 = "txt/Sentence1" + suffix + ".txt"
	part2 = "txt/Sentence2" + suffix + ".txt"
	part3 = "txt/Sentence3" + suffix + ".txt"
	send  = "txt/Senders" + suffix + ".txt"

	emailString  = ""

	#emailString  = randLine("txt/Greetings.txt") + "\n"
	emailString  = randLine(greet) + "\n"

	#emailString += randLine("txt/Sentence1.txt")
	emailString += randLine(part1)

	emailString += randLine(part2) + " "
	#emailString += randLine(part2) + " "

	emailString += randLine(part3) + "\n"
	#emailString += randLine(part3) + "\n"

	emailString += randLine("txt/Ending.txt") + "\n"

	#emailString += randLine("txt/Senders.txt")
	emailString += randLine(send)


	emailString = emailString.replace("[NAME]",inName)
	emailString = emailString.replace("[LINK EXPLANATION]",randLine("txt/Link_Explanations.txt"))
	emailString = emailString.replace("[RANDNUM]",str(randint(2,10)))
	emailString = emailString.replace("[COUNTRY]",randLine("txt/Countries.txt"))
	emailString = emailString.replace("[RANDTIME]", str(randint(0,24)) + ":" + str(randint(0,5)) + str(randint(0,9)))

	return emailString

#generates email of random type
#" "
#"Easy"
#"Finance"
#"Academic"
def genEmail(inName, inSuffix):
        if (inSuffix == ""):
		inSuffix = randLine("txt/Suffix.txt")
        elif (inSuffix == " "):
		inSuffix = ""
	else:
		inSuffix = "_" + inSuffix
	return genText(inName, inSuffix)

